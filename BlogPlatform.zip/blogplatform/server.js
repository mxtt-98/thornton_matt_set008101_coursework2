
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/blogstore');
var connection = mongoose.connection;

connection.on('connected',function(){
  console.log('connected to db')
});
var PostSchema = mongoose.Schema({ //declares the setup for the mongodb database
    title: {type: String, required: true},
    content: String,
    posted: {type: Date, default: Date.now}
}, {collection: 'post'});

var PostModel = mongoose.model("PostModel", PostSchema); //creates the new posts based on the schema given above

app.use(express.static(__dirname + '/public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.post("/api/BlogEntry", createPost);
app.get("/api/BlogEntry", getAllposts);
app.delete("/api/BlogEntry/:id", deletePost);
app.get("/api/BlogEntry/:id", retrievePost);
app.put("/api/BlogEntry/:id", updatePost);


function updatePost(req, res) {
  var postId = req.params.id;
  var post = req.body;
  PostModel
    .update({_id: postId},{
      title: post.title,
      content:post.content
    })
    .then(
      function(status){
        res.sendStatus(200);
      },
      function(err){
        res.sendStatus(400);
      }
    );
}

function retrievePost(req,res){
  var postId = req.params.id;
  PostModel
    .findById({_id:postId})
    .then(
      function(post){
        res.json(post);
      },
      function(err){
        res.sendStatus(400);
      }
  );
}

function deletePost(req, res){
  var postId = req.params.id;
  PostModel
    .remove({_id: postId})
    .then(
      function (status) {
        res.sendStatus(200);
      },
      function(){
        res.sendStatus(400);
      }
    );
}

function getAllposts(req,res){
  PostModel
    .find()
    .then(
      function(posts){
        res.json(posts);
      },
      function(err){
        res.sendStatus(400);
      }
    );
}

function createPost(req,res){
  var post = req.body;
  console.log(post);
  PostModel
      .create(post)
      .then(
        function (postObj){
            res.json(200);
        },
        function(err){
          res.sendStatus(400);
        }
      )

}
app.listen(3000);
